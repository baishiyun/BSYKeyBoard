//
//  ViewController.m
//  BSYKeyboard
//
//  Created by 白仕云 on 2018/5/28.
//  Copyright © 2018年 BSY.com. All rights reserved.
//

#import "ViewController.h"
#import "BSYTextFiled.h"
@interface ViewController ()
@property (nonatomic ,strong)BSYTextFiled *textField;
@end

@implementation ViewController

- (void)viewDidLoad {

    [super viewDidLoad];

    self.textField = [[BSYTextFiled alloc] initWithFrame:CGRectMake(100, 100, 200, 40) showKeyBoardType:BSYPayType];
    self.textField.backgroundColor = [UIColor grayColor];
    [self.view addSubview:self.textField];

    BSYTextFiled *textField = [[BSYTextFiled alloc] initWithFrame:CGRectMake(100, 200, 200, 40) showKeyBoardType:BSYIDCardType];
    textField.backgroundColor = [UIColor greenColor];
    [self.view addSubview:textField];
}

@end
